package com.headunit.launcher

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NavigationPolicyTest {
    @Test fun speedZoomIsCloserWhenSlowAndWiderAtSpeed() {
        assertEquals(18.4, NavigationPolicy.speedZoom(0.0), 0.0001)
        assertEquals(15.7, NavigationPolicy.speedZoom(40.0), 0.0001)
        assertTrue(NavigationPolicy.speedZoom(8.0) > NavigationPolicy.speedZoom(30.0))
        assertTrue(NavigationPolicy.speedZoom(0.0) > NavigationPolicy.speedZoom(10.0))
        assertTrue(NavigationPolicy.speedZoom(10.0) > NavigationPolicy.speedZoom(25.0))
        assertTrue(NavigationPolicy.speedZoom(25.0) > NavigationPolicy.speedZoom(40.0))
    }

    @Test fun speedZoomClampsAndHandlesInvalidSpeed() {
        assertEquals(18.4, NavigationPolicy.speedZoom(-4.0), 0.0001)
        assertEquals(15.7, NavigationPolicy.speedZoom(100.0), 0.0001)
        assertEquals(15.7, NavigationPolicy.speedZoom(Double.NaN), 0.0001)
    }

    @Test fun routeZoomAdjustsForRoadType() {
        val town = NavigationPolicy.routeSpeedZoom(15.0, "street")
        val motorway = NavigationPolicy.routeSpeedZoom(15.0, "motorway")
        assertTrue(town > motorway)
        assertEquals(18.7, NavigationPolicy.routeSpeedZoom(0.0, null), 0.0001)
        assertEquals(15.6, NavigationPolicy.routeSpeedZoom(36.0, null), 0.0001)
    }

    @Test fun poorGpsAccuracyCannotTriggerReroute() {
        assertTrue(NavigationPolicy.gpsReliableForReroute(0.0)) // unknown accuracy from older providers
        assertTrue(NavigationPolicy.gpsReliableForReroute(45.0))
        assertFalse(NavigationPolicy.gpsReliableForReroute(45.1))
        assertFalse(NavigationPolicy.gpsReliableForReroute(100.0))
    }

    @Test fun roundaboutGuidanceDoesNotShowRawLeftTurnMessage() {
        val step = Step(300.0, "ROUNDABOUT_CROSS", "", "Turn left", 2)
        assertEquals("at the roundabout, take the 2nd exit", Geo.guidanceLabel(step))
    }

    @Test fun roundaboutKeepsRoadNameWhenAvailable() {
        val step = Step(300.0, "ROUNDABOUT_CROSS", "A3057", "Turn left", 2)
        assertEquals("A3057", Geo.guidanceLabel(step))
    }

    @Test fun zoomChangesAreDamped() {
        assertEquals(15.1, NavigationPolicy.smoothZoom(15.0, 16.0), 0.0001)
        assertEquals(14.9, NavigationPolicy.smoothZoom(15.0, 14.0), 0.0001)
        assertEquals(16.0, NavigationPolicy.smoothZoom(0.0, 16.0), 0.0001)
    }
    @Test fun gpsReroutePolicyHandlesBoundaryAndNonFiniteValues() {
        assertTrue(NavigationPolicy.gpsReliableForReroute(45.0))
        assertFalse(NavigationPolicy.gpsReliableForReroute(45.01))
        assertTrue(NavigationPolicy.gpsReliableForReroute(Double.NaN))
        assertTrue(NavigationPolicy.gpsReliableForReroute(Double.POSITIVE_INFINITY))
    }

    @Test fun smoothZoomDoesNotOvershootTarget() {
        assertEquals(15.1, NavigationPolicy.smoothZoom(15.0, 100.0), 0.0001)
        assertEquals(14.9, NavigationPolicy.smoothZoom(15.0, -100.0), 0.0001)
        assertEquals(15.0, NavigationPolicy.smoothZoom(15.0, 100.0, -1.0), 0.0001)
    }

}

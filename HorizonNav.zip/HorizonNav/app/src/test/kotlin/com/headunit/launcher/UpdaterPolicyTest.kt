package com.headunit.launcher

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class UpdaterPolicyTest {
    @Test fun acceptsSha256HexAndNormalizesCaseAndWhitespace() {
        val digest = "ABCDEF0123456789".repeat(4)
        assertEquals(digest.lowercase(), Updater.parseSha256("  $digest\n"))
    }

    @Test fun rejectsMissingOrMalformedSha256() {
        assertNull(Updater.parseSha256(""))
        assertNull(Updater.parseSha256("0".repeat(63)))
        assertNull(Updater.parseSha256("0".repeat(65)))
        assertNull(Updater.parseSha256("g".repeat(64)))
        assertNull(Updater.parseSha256("0".repeat(63) + " "))
    }
}

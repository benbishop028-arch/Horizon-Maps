package com.headunit.launcher

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Update check for the shareable app: looks at the "app" release on GitHub (published by the build's "publish" option) and,
 * when it holds a newer build, downloads the APK and hands it to Android's installer. The personal build has no update repo,
 * so it never checks (its APK is never published).
 */
object Updater {
    class Update(val version: String, val build: Int, val url: String)

    val enabled: Boolean get() = BuildConfig.UPDATE_REPO.isNotBlank()

    /** The build number of this app (each GitHub build counts up; versionCode is 100 + build). */
    val thisBuild: Int get() = BuildConfig.VERSION_CODE - 100

    /** Asks GitHub for the published app. Returns it when it's newer than this one, null when it isn't (or can't be checked). */
    fun check(): Update? {
        if (!enabled) return null
        val c = URL("https://api.github.com/repos/${BuildConfig.UPDATE_REPO}/releases/tags/app").openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 20000
        c.setRequestProperty("User-Agent", "HorizonNav/${BuildConfig.VERSION_NAME}")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        try {
            if (c.responseCode !in 200..299) return null
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            val text = j.optString("name") + " " + j.optString("body")
            val m = Regex("1\\.0\\.(\\d+)").find(text) ?: return null
            val build = m.groupValues[1].toIntOrNull() ?: return null
            val assets = j.optJSONArray("assets") ?: return null
            var url = ""
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name") == BuildConfig.UPDATE_APK) url = a.optString("browser_download_url")
            }
            if (url.isBlank() || build <= thisBuild) return null
            return Update("1.0.$build", build, url)
        } finally { c.disconnect() }
    }

    /** True when Android will let this app open the installer (on Android 8 and later it's a per-app setting). */
    fun canInstall(ctx: Context): Boolean = Build.VERSION.SDK_INT < 26 || ctx.packageManager.canRequestPackageInstalls()

    /** Opens the setting where you allow Horizon Nav to install updates. */
    fun openInstallSetting(ctx: Context) {
        try {
            ctx.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            ctx.startActivity(Intent(android.provider.Settings.ACTION_SECURITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    /** Opens the download in the browser instead (for head units without Android's download service). */
    fun openInBrowser(ctx: Context, u: Update) {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /**
     * Downloads the new APK with Android's download service (it carries on in the background and copes with signal drops),
     * waiting here until it's done, then opens the installer. [progress] gets short status lines. Throws when it can't.
     */
    fun downloadAndInstall(ctx: Context, u: Update, progress: (String) -> Unit) {
        val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager ?: throw IllegalStateException("No download service")
        val dir = ctx.getExternalFilesDir(null) ?: throw IllegalStateException("No storage")
        val name = "HorizonNav-${u.version}.apk"
        // older downloaded updates are no longer needed
        dir.listFiles()?.filter { it.name.startsWith("HorizonNav-") && it.name.endsWith(".apk") }?.forEach { it.delete() }
        val req = DownloadManager.Request(Uri.parse(u.url))
            .setTitle("Horizon Nav ${u.version}")
            .setMimeType("application/vnd.android.package-archive")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
            .setDestinationInExternalFilesDir(ctx, null, name)
        val id = dm.enqueue(req)
        progress("Downloading…")
        while (true) {
            Thread.sleep(700)
            dm.query(DownloadManager.Query().setFilterById(id)).use { cur ->
                if (cur == null || !cur.moveToFirst()) throw IllegalStateException("Download was cancelled")
                val status = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val done = cur.getLong(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                val total = cur.getLong(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                when (status) {
                    DownloadManager.STATUS_SUCCESSFUL -> {
                        val uri = dm.getUriForDownloadedFile(id) ?: throw IllegalStateException("Download missing")
                        progress("Opening the installer…")
                        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                        ctx.startActivity(i)
                        return
                    }
                    DownloadManager.STATUS_FAILED -> { dm.remove(id); throw IllegalStateException("Download failed") }
                    else -> if (total > 0) progress("Downloading… ${done * 100 / total}%")
                }
            }
        }
    }

    /** The file the last update was saved as (cleared once a newer app is running). */
    fun cleanUp(ctx: Context) {
        val dir = ctx.getExternalFilesDir(null) ?: return
        dir.listFiles()?.filter { it.name.startsWith("HorizonNav-") && it.name.endsWith(".apk") }?.forEach { f ->
            val b = Regex("1\\.0\\.(\\d+)").find(f.name)?.groupValues?.get(1)?.toIntOrNull() ?: return@forEach
            if (b <= thisBuild) f.delete()
        }
    }
}

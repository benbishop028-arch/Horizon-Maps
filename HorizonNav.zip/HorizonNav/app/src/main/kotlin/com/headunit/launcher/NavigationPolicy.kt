package com.headunit.launcher

/** Pure navigation policies kept separate so their edge cases can be covered by local unit tests. */
internal object NavigationPolicy {
    private val freeDriveSpeedPoints = doubleArrayOf(0.0, 3.0, 6.0, 11.0, 17.0, 24.0, 31.0, 40.0)
    private val freeDriveZoomPoints = doubleArrayOf(18.4, 18.1, 17.8, 17.3, 16.9, 16.5, 16.2, 16.0)
    private val routeSpeedPoints = doubleArrayOf(0.0, 4.0, 8.0, 11.0, 13.4, 17.0, 22.0, 27.0, 31.0, 36.0)
    private val routeZoomPoints = doubleArrayOf(18.7, 18.5, 18.2, 17.9, 17.6, 17.1, 16.6, 16.2, 15.9, 15.6)

    /** Interpolated free-drive zoom. Cached point arrays avoid allocating two arrays on every camera tick. */
    fun speedZoom(speedMps: Double): Double {
        if (!speedMps.isFinite()) return freeDriveZoomPoints.last()
        if (speedMps <= freeDriveSpeedPoints.first()) return freeDriveZoomPoints.first()
        if (speedMps >= freeDriveSpeedPoints.last()) return freeDriveZoomPoints.last()
        for (i in 1 until freeDriveSpeedPoints.size) {
            if (speedMps <= freeDriveSpeedPoints[i]) {
                val fraction = (speedMps - freeDriveSpeedPoints[i - 1]) /
                    (freeDriveSpeedPoints[i] - freeDriveSpeedPoints[i - 1])
                return freeDriveZoomPoints[i - 1] +
                    (freeDriveZoomPoints[i] - freeDriveZoomPoints[i - 1]) * fraction
            }
        }
        return freeDriveZoomPoints.last()
    }

    /** Route zoom interpolation plus a modest road-class adjustment, with no per-frame array allocation. */
    fun routeSpeedZoom(speedMps: Double, roadClass: String?): Double {
        val base = interpolate(speedMps, routeSpeedPoints, routeZoomPoints)
        return when {
            roadClass == null -> base
            roadClass.startsWith("motorway") || roadClass.startsWith("trunk") -> base - 0.35
            roadClass == "street" || roadClass == "street_limited" || roadClass == "service" -> base + 0.3
            else -> base
        }
    }

    private fun interpolate(value: Double, xs: DoubleArray, ys: DoubleArray): Double {
        if (!value.isFinite() || value >= xs.last()) return ys.last()
        if (value <= xs.first()) return ys.first()
        for (i in 1 until xs.size) if (value <= xs[i]) {
            val fraction = (value - xs[i - 1]) / (xs[i] - xs[i - 1])
            return ys[i - 1] + (ys[i] - ys[i - 1]) * fraction
        }
        return ys.last()
    }

    /** Unknown accuracy is allowed for compatibility; known poor fixes should not trigger a reroute. */
    fun gpsReliableForReroute(accuracyMeters: Double): Boolean =
        !accuracyMeters.isFinite() || accuracyMeters <= 0.0 || accuracyMeters <= 45.0

    /** Smooths zoom at a fixed maximum change per camera update to avoid visible zoom pulses. */
    fun smoothZoom(current: Double, target: Double, maxStep: Double = 0.10): Double {
        if (!current.isFinite() || current <= 0.0) return target
        val step = maxStep.coerceAtLeast(0.0)
        return current + (target - current).coerceIn(-step, step)
    }
}

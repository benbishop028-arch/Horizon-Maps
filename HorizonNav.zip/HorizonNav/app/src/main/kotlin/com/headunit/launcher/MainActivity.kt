package com.headunit.launcher

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.snapshotFlow
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import com.headunit.launcher.ui.App
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private lateinit var map: MapBinding
    private lateinit var engine: NavEngine

    private val perm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    private fun hasLocation() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** A route is being followed (not just previewed) or the demo drive is on, so guidance should carry on when another app is in front. */
    private fun guiding() = (engine.route != null && !engine.previewing) || engine.simMode != 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // keep the last crash so it can be read in Settings > About & backup
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        val crashFile = java.io.File(applicationContext.filesDir, "lastcrash.txt")
        val boot = getSharedPreferences(CrashGuardPrefs.FILE, android.content.Context.MODE_PRIVATE)
        val startedAt = System.currentTimeMillis()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { crashFile.writeText("Thread ${t.name}\n" + android.util.Log.getStackTraceString(e).take(3000)) } catch (x: Throwable) { }
            // a crash in the first 25 seconds counts as "crashed while starting"
            try { if (System.currentTimeMillis() - startedAt < 25_000L) boot.edit().putInt(CrashGuardPrefs.START_FAILURES, boot.getInt(CrashGuardPrefs.START_FAILURES, 0) + 1).commit() } catch (x: Throwable) { }
            prev?.uncaughtException(t, e)
        }
        // freezes ("isn't responding") don't reach the crash handler: watch for them, and pick up Android's record of the last one
        FreezeWatch.start(applicationContext)
        Thread { FreezeWatch.collectLastExit(applicationContext) }.start()
        // it crashed while starting twice running: show a plain page that can send the crash report (it doesn't start the map),
        // instead of crashing again before anything can be tapped
        if (boot.getInt(CrashGuardPrefs.START_FAILURES, 0) >= 2 && crashFile.exists()) {
            setContent { StartupCrashPage(crashReport(crashFile)) { boot.edit().putInt(CrashGuardPrefs.START_FAILURES, 0).commit(); recreate() } }
            return
        }
        // running fine for 25 seconds: clear the count
        window.decorView.postDelayed({ try { boot.edit().putInt(CrashGuardPrefs.START_FAILURES, 0).apply() } catch (x: Throwable) { } }, 25_000L)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideBars()
        // on Android 10 and older the bars come back whenever anything pops up (a dialog, the keyboard, a system message): hide them again
        @Suppress("DEPRECATION")
        window.decorView.setOnSystemUiVisibilityChangeListener { vis ->
            if (vis and android.view.View.SYSTEM_UI_FLAG_FULLSCREEN == 0) window.decorView.postDelayed({ if (!isFinishing) hideBars() }, 2500)
        }

        val prefs = Prefs(applicationContext)
        // the Mapbox map needs OpenGL ES 3.0: on an older unit, say so plainly instead of showing a black map (or closing)
        val gl = try { (getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager).deviceConfigurationInfo.reqGlEsVersion } catch (e: Throwable) { 0x30000 }
        if (gl in 1 until 0x30000) {
            setContent { NoGlesPage(gl) }
            return
        }
        // the Mapbox token from Settings, before the map is made
        val tok = prefs.s(PreferenceKeys.MAPBOX_TOKEN, "").trim()
        try { prefs.migrateToMapbox() } catch (e: Throwable) { }
        if (tok.isNotEmpty()) try { com.mapbox.common.MapboxOptions.accessToken = tok } catch (e: Throwable) { }
        map = MapBinding(this, prefs.b("mapfast", true), (prefs.s(PreferenceKeys.MAP_RESOLUTION, "80").toIntOrNull() ?: 80) / 100f).also { it.setArrowScale((prefs.s(PreferenceKeys.ARROW_PERCENT, "240").toIntOrNull() ?: 240) / 100f) }
        lifecycle.addObserver(map)
        // open where you were last time (the GPS takes over as soon as it answers)
        try {
            val sp = prefs.s("startpos", "").split(',')
            val la = sp.getOrNull(0)?.toDoubleOrNull(); val lo = sp.getOrNull(1)?.toDoubleOrNull(); val br = sp.getOrNull(2)?.toDoubleOrNull()
            if (la != null && lo != null) map.startAt(LL(la, lo), br?.takeIf { it >= 0 })
        } catch (e: Throwable) { }
        engine = NavEngine(applicationContext, prefs, map)

        setContent { App(prefs, engine, map) }

        // while a route runs, a foreground service keeps GPS and voice going in the background; it stops when the route ends
        lifecycleScope.launch {
            snapshotFlow { if (guiding()) (engine.dest?.name ?: "your destination") else null }
                .distinctUntilChanged()
                .collect { to ->
                    if (to != null && hasLocation()) NavService.start(applicationContext, "Navigating to $to")
                    else if (to == null) {
                        NavService.stop(applicationContext)
                        // the route ended (arrived or cancelled) while another app was in front: GPS can rest too
                        if (!lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.STARTED)) engine.stopLocation()
                    }
                }
        }

        if (savedInstanceState == null) handleShared(intent)

        val wanted = arrayListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) wanted += Manifest.permission.POST_NOTIFICATIONS
        val missing = wanted.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) perm.launch(missing.toTypedArray())
    }

    /** Hides the status and navigation bars: the newer way, plus the older flags that Android 10 and older head units go by. */
    private fun hideBars() {
        try {
            window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            WindowCompat.setDecorFitsSystemWindows(window, false)
            WindowInsetsControllerCompat(window, window.decorView).apply {
                hide(WindowInsetsCompat.Type.systemBars())
                systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
            if (Build.VERSION.SDK_INT < 30) {
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = (android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                    android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
            }
        } catch (e: Exception) { }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // coming back from another app, a dialog or the notification shade: the bars may be showing again
        if (hasFocus) hideBars()
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (::engine.isInitialized) handleShared(intent)
    }

    /** A destination shared from another app (a Google Maps link, a geo: link or an address). */
    private fun handleShared(i: android.content.Intent?) {
        val text = ExternalLinks.textOf(i) ?: return
        lifecycleScope.launch {
            val t = try { kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { ExternalLinks.parse(text) } } catch (e: Exception) { null }
            // wait (briefly) for a first position so the route can start from where you are
            var n = 0
            while (t?.pos != null && engine.fix == null && n < 20) { kotlinx.coroutines.delay(500); n++ }
            if (t != null) engine.openShared(t) else engine.toast("Couldn't read a place from that", 3500)
        }
    }

    override fun onResume() {
        super.onResume()
        hideBars()
        if (!::engine.isInitialized) return
        // back in front: look for a new version and new map data
        engine.onOpened()
        // after the permission dialog closes, wait a beat so the UI is settled before starting GPS
        if (hasLocation()) window.decorView.postDelayed({ if (!isFinishing && !isDestroyed) engine.startLocation() }, 400)
    }

    override fun onStart() {
        super.onStart()
        if (::engine.isInitialized) engine.appVisible = true
    }

    override fun onStop() {
        super.onStop()
        if (!::engine.isInitialized) return
        engine.appVisible = false
        // with no route there is nothing to guide, so GPS is switched off while the app is in the background
        if (!guiding()) engine.stopLocation()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (!::engine.isInitialized) return
        NavService.stop(applicationContext)
        engine.shutdown()
    }
}

/** The crash report for the startup-crash page: the app, the unit and what went wrong. */
private fun crashReport(f: java.io.File): String = buildString {
    appendLine("Horizon Nav ${BuildConfig.VERSION_NAME} (${BuildConfig.FLAVOR}) crashed while starting")
    appendLine("Unit: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), 64-bit: ${Build.SUPPORTED_64_BIT_ABIS.isNotEmpty()} (${Build.SUPPORTED_ABIS.joinToString()})")
    appendLine()
    append(try { f.readText().take(3000) } catch (e: Exception) { "(couldn't read the crash)" })
}

@androidx.compose.runtime.Composable
private fun NoGlesPage(gl: Int) {
    val bg = androidx.compose.ui.graphics.Color(0xFF15171C)
    val fg = androidx.compose.ui.graphics.Color(0xFFF2F3F5)
    androidx.compose.foundation.layout.Column(
        androidx.compose.ui.Modifier.fillMaxSize().background(bg).verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(32.dp),
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(14.dp),
    ) {
        androidx.compose.material3.Text("This head unit can't draw the Mapbox map", color = fg, fontSize = 24.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        androidx.compose.material3.Text("Horizon Nav needs OpenGL ES 3.0 graphics, and this unit has version ${gl shr 16}.${gl and 0xFFFF}. " +
            "Versions of Horizon Nav from before the Mapbox map work on older graphics, if you still have one.", color = fg.copy(alpha = 0.8f), fontSize = 16.sp)
    }
}

@androidx.compose.runtime.Composable
private fun StartupCrashPage(report: String, onRetry: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val bg = androidx.compose.ui.graphics.Color(0xFF15171C)
    val fg = androidx.compose.ui.graphics.Color(0xFFF2F3F5)
    androidx.compose.foundation.layout.Column(
        androidx.compose.ui.Modifier.fillMaxSize().background(bg).verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(32.dp),
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(14.dp),
    ) {
        androidx.compose.material3.Text("Horizon Nav keeps closing while it starts", color = fg, fontSize = 24.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        androidx.compose.material3.Text("Sorry about that. Sending the report below lets it be fixed for this head unit. Nothing personal is in it.", color = fg.copy(alpha = 0.75f), fontSize = 15.sp)
        androidx.compose.foundation.layout.Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp)) {
            androidx.compose.material3.Button({
                val url = "https://github.com/${BuildConfig.UPDATE_REPO}/issues/new?title=" + android.net.Uri.encode("Crash on start: ${Build.MANUFACTURER} ${Build.MODEL}") + "&body=" + android.net.Uri.encode(report.take(5000))
                try { ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }
                catch (e: Exception) { android.widget.Toast.makeText(ctx, "No browser on this unit: use Copy instead", android.widget.Toast.LENGTH_LONG).show() }
            }) { androidx.compose.material3.Text("Send on GitHub") }
            androidx.compose.material3.Button({
                val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                cm?.setPrimaryClip(android.content.ClipData.newPlainText("Horizon Nav crash", report))
                android.widget.Toast.makeText(ctx, "Copied: paste it into a message or a Reddit comment", android.widget.Toast.LENGTH_LONG).show()
            }) { androidx.compose.material3.Text("Copy") }
            androidx.compose.material3.OutlinedButton(onRetry) { androidx.compose.material3.Text("Try again", color = fg) }
        }
        androidx.compose.material3.Text(report, color = fg.copy(alpha = 0.6f), fontSize = 11.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
    }
}

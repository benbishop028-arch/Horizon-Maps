# Horizon Nav architecture notes

This document records current ownership boundaries and the intended low-risk refactoring order. It is deliberately not a claim that the large navigation files have already been split.

## Current responsibilities

- `ui/`: Compose screens and presentation. Keep view state and interaction here; move reusable policy/validation out when it can be tested without Android UI.
- `NavEngine.kt`: navigation orchestration and route/session state. This is currently the largest file and should be split incrementally by cohesive responsibility, preserving its public API while each extraction is tested.
- `MapBinding.kt`: Mapbox view/style/lifecycle integration. Keep SDK objects and lifecycle ownership here; extract pure style/zoom decisions into policy files rather than moving SDK-dependent code blindly.
- `Geo.kt`, `NavigationPolicy.kt`: geographic calculations and pure navigation decisions. Prefer unit tests for edge cases before changing callers.
- `OfflineRouter.kt`, `OfflineMap.kt`, `OfflinePlaces.kt`, `OfflineServer.kt`: offline routing, map/places access, and loopback serving. Keep network parsing and request limits close to their boundaries.
- `Prefs.kt`: observable preferences, backup import/export, and compatibility migrations. New key names and migrations should be documented and tested; never include API keys in exported backups.
- `Updater.kt`: Android/GitHub/download/install I/O. Pure metadata validation is now in `UpdaterPolicy.kt`, so it can be tested independently of Android services.

## Refactoring rules

1. Keep existing package names, application IDs, preference names, and persisted formats stable unless a migration is explicitly included.
2. Extract small pure functions first; avoid broad moves of SDK-coupled code in one change.
3. Add tests around the extracted behavior before changing call sites.
4. Preserve lifecycle ownership and cancellation when moving asynchronous work.
5. Do not publish a release or change signing credentials as part of a source refactor.
6. Run unit tests and a release build in GitHub Actions before installing a refactored APK on a head unit.

## Next safe extractions

1. Extract `NavEngine.kt` route matching / reroute decision helpers where inputs and outputs can be represented without Mapbox or Android objects.
2. Extract `MapBinding.kt` style selection and layer-configuration policy, keeping SDK mutations in `MapBinding`.
3. Centralize preference keys in small groups with compatibility tests; do not bulk-rename persisted keys.
4. Replace blocking retry loops only when their calling thread and cancellation/lifecycle contract are established.

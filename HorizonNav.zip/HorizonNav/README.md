# Horizon Nav

Horizon Nav is a standalone navigation app for Android head units, with an Android Auto interface.

## Features

- Mapbox map, search, routing, lane guidance, live traffic, speed limits, cameras and voice guidance.
- TomTom REST API support for search and route/traffic fallback. Supply a key at build time with `-PtomtomApiKey=YOUR_KEY` or enter one in Settings.
- Offline map, search and routing using the England & Wales (or Great Britain) pack.
- Average-speed checks, motorway services, speed-bump and school warnings, and Clean Air Zone / ULEZ warnings and avoidance using OpenStreetMap data.
- UK fuel prices from the government's Fuel Finder scheme (requires your own client ID and secret), with route-aware searches for fuel, chargers, food, coffee, toilets and services.
- Route stops with reordering, "avoid this road", destination side, reports, tunnel dead reckoning, road/heading card when driving without a route, and trip log.
- Destinations shared from other apps, including Google Maps links, `geo:` links and addresses.
- Background guidance while a route is active, using a foreground service and notification.

## Build

```sh
gradle :app:assembleRelease -PtomtomApiKey=YOUR_KEY
```

The release flavor uses application ID `com.headunit.nav.public` to remain compatible with existing Horizon Nav installations. Do not change the application ID or signing key for an update release unless you have planned a migration; Android requires a compatible signing certificate to install updates over an existing app.

GitHub Actions builds directly from the checked-out Gradle source tree when available, with `HorizonNav.zip` retained as a fallback for archive-only repositories. Published update releases include `version.json` machine-readable version metadata and a SHA-256 sidecar file, both checked by the app before offering/installing an update. The workflow deliberately fails if the existing `signing.keystore` is missing rather than generating a replacement that could break updates. The release signing configuration and updater release channel are maintained in that workflow.

R8 code shrinking and resource shrinking remain disabled intentionally. Horizon Nav relies on reflection and runtime-loaded resources across Compose, Mapbox, Android Car App and the offline routing library; enabling shrinking without a successful release build and real-device navigation regression pass would risk breaking features. Revisit this only as a separate, test-backed change.

package com.headunit.launcher

import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Something along the route from OpenStreetMap: motorway services, a speed bump or a school. */
class RoutePoi(val kind: String, val name: String, val pos: LL)

/** An average speed check from OpenStreetMap: where it starts and ends, and its limit (m/s, or null when not mapped). */
class AvgDef(val id: Long, val name: String, val starts: List<LL>, val ends: List<LL>, val limit: Double?)

/**
 * Average speed checks found before, kept on the device (files/avgzones.json), so a road driven before shows its check straight
 * away, even with no signal or a busy lookup server (GitHub #135). Refreshed whenever a lookup of the same area succeeds.
 */
object AvgCache {
    private var all: List<AvgDef> = emptyList()
    @Volatile private var loaded = false
    private fun file(ctx: android.content.Context) = java.io.File(ctx.filesDir, "avgzones.json")

    @Synchronized fun load(ctx: android.content.Context) {
        if (loaded) return
        loaded = true
        all = try {
            val a = org.json.JSONArray(file(ctx).readText())
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                fun pts(k: String) = o.getJSONArray(k).let { p -> (0 until p.length()).map { j -> p.getJSONArray(j).let { LL(it.getDouble(0), it.getDouble(1)) } } }
                AvgDef(o.getLong("id"), o.optString("name"), pts("s"), pts("e"), if (o.has("lim")) o.getDouble("lim") else null)
            }
        } catch (e: Exception) { emptyList() }
    }

    /** The ones round this stretch of road (with a few km to spare). */
    @Synchronized fun near(line: List<LL>): List<AvgDef> {
        if (line.isEmpty() || all.isEmpty()) return emptyList()
        var minLat = 90.0; var maxLat = -90.0; var minLon = 180.0; var maxLon = -180.0
        for (p in line) { minLat = min(minLat, p.lat); maxLat = max(maxLat, p.lat); minLon = min(minLon, p.lon); maxLon = max(maxLon, p.lon) }
        return all.filter { d -> (d.starts + d.ends).any { it.lat in (minLat - 0.03)..(maxLat + 0.03) && it.lon in (minLon - 0.045)..(maxLon + 0.045) } }
    }

    /** Stores what a lookup of [line]'s area found: new ones added, changed ones replaced, ones gone from the map dropped. */
    @Synchronized fun put(ctx: android.content.Context, line: List<LL>, found: List<AvgDef>) {
        if (line.isEmpty()) return
        var minLat = 90.0; var maxLat = -90.0; var minLon = 180.0; var maxLon = -180.0
        for (p in line) { minLat = min(minLat, p.lat); maxLat = max(maxLat, p.lat); minLon = min(minLon, p.lon); maxLon = max(maxLon, p.lon) }
        fun inside(d: AvgDef) = (d.starts + d.ends).all { it.lat in (minLat - 0.01)..(maxLat + 0.01) && it.lon in (minLon - 0.015)..(maxLon + 0.015) }
        val ids = found.map { it.id }.toSet()
        all = (all.filter { it.id !in ids && !inside(it) } + found).takeLast(500)
        try {
            val a = org.json.JSONArray()
            for (d in all) {
                fun arr(p: List<LL>) = org.json.JSONArray().also { j -> p.forEach { j.put(org.json.JSONArray().put(it.lat).put(it.lon)) } }
                a.put(JSONObject().put("id", d.id).put("name", d.name).put("s", arr(d.starts)).put("e", arr(d.ends)).also { o -> d.limit?.let { o.put("lim", it) } })
            }
            val f = file(ctx); val tmp = java.io.File(f.path + ".tmp"); tmp.writeText(a.toString()); tmp.renameTo(f)
        } catch (e: Exception) { }
    }
}

/** The same things placed on a particular route, by distance from the route start (metres). */
class PoiOnRoute(val poi: RoutePoi, val off: Double, val side: Double)
class AvgOnRoute(val def: AvgDef, val start: Double, val end: Double)

/** Live state of the average speed check you are in. */
/** [safeMs]: the most you can do for the rest of the zone and still average under the limit (0 = can't any more; null = not known yet). */
class AvgInfo(val avgMs: Double, val limitMs: Double?, val leftM: Double, val over: Boolean, val ahead: Boolean, val toStartM: Double, val safeMs: Double? = null)

/** Next motorway services ahead. */
class ServiceAhead(val name: String, val dist: Double, val fuel: String)

/** A marker on the route bar: what it is and how far along the route. */
class BarEvent(val off: Double, val kind: String)

object RouteExtras {
    /** Points along the route between two distances, about every [step] metres (used as an Overpass "around" line). */
    fun line(r: Route, from: Double, to: Double, step: Double, maxPts: Int): List<LL> {
        val out = ArrayList<LL>()
        if (r.pts.size < 2) return out
        val a = max(0.0, from); val b = min(r.len, to)
        if (b <= a) return out
        val st = max(step, (b - a) / maxPts)
        var last = -1e9
        for (i in r.pts.indices) {
            val c = r.cum[i]
            if (c < a) continue
            if (c > b) { out += r.pts[i]; break }
            if (c - last >= st) { out += r.pts[i]; last = c }
        }
        if (out.size == 1) out += r.pts.last()
        return out
    }

    /** Distance along the route of the closest point to [p], and how far [p] is from the route. Null when it is further than [maxOff]. */
    fun project(r: Route, p: LL, maxOff: Double, fromOff: Double = 0.0): Pair<Double, Double>? {
        val pts = r.pts
        if (pts.size < 2) return null
        val kx = cos(Math.toRadians(p.lat)) * 111320.0
        val ky = 110574.0
        var bd = maxOff; var bo = -1.0
        var i = 0
        while (i < pts.size - 1) {
            if (r.cum[i + 1] < fromOff) { i++; continue }
            val ax = (pts[i].lon - p.lon) * kx; val ay = (pts[i].lat - p.lat) * ky
            val bx = (pts[i + 1].lon - p.lon) * kx; val by = (pts[i + 1].lat - p.lat) * ky
            // the whole segment lies well off to one side: it cannot be the closest
            if ((ax > maxOff && bx > maxOff) || (ax < -maxOff && bx < -maxOff) || (ay > maxOff && by > maxOff) || (ay < -maxOff && by < -maxOff)) { i++; continue }
            val dx = bx - ax; val dy = by - ay
            val l2 = dx * dx + dy * dy
            val t = if (l2 > 0) (-(ax * dx + ay * dy) / l2).coerceIn(0.0, 1.0) else 0.0
            val d = hypot(ax + dx * t, ay + dy * t)
            if (d < bd) { bd = d; bo = r.cum[i] + (r.cum[i + 1] - r.cum[i]) * t }
            i++
        }
        return if (bo >= 0) bo to bd else null
    }

    private fun poly(line: List<LL>) = line.joinToString(",") { String.format(java.util.Locale.US, "%.5f,%.5f", it.lat, it.lon) }

    /** Motorway services and rest areas next to the route (blocking). */
    fun services(line: List<LL>): List<RoutePoi> {
        if (line.size < 2) return emptyList()
        val els = Overpass.query("[out:json][timeout:40];(node(around:350,${poly(line)})[\"highway\"~\"^(services|rest_area)$\"];way(around:350,${poly(line)})[\"highway\"~\"^(services|rest_area)$\"];);out center tags 120;", 12000, 50000, 3)
        val out = ArrayList<RoutePoi>()
        for (i in 0 until els.length()) {
            val e = els.getJSONObject(i)
            val t = e.optJSONObject("tags") ?: JSONObject()
            val pos = if (e.has("lat")) LL(e.getDouble("lat"), e.getDouble("lon")) else e.optJSONObject("center")?.let { LL(it.getDouble("lat"), it.getDouble("lon")) } ?: continue
            val rest = t.optString("highway") == "rest_area"
            val name = t.optString("name").ifBlank { t.optString("operator") }.ifBlank { if (rest) "Rest area" else "Services" }
            out += RoutePoi(if (rest) "rest" else "services", name, pos)
        }
        return out
    }

    /** Speed bumps and schools right next to the route, and average speed checks around it (blocking). */
    fun hazards(line: List<LL>): Pair<List<RoutePoi>, List<AvgDef>> {
        if (line.size < 2) return emptyList<RoutePoi>() to emptyList()
        var minLat = 90.0; var maxLat = -90.0; var minLon = 180.0; var maxLon = -180.0
        for (p in line) { minLat = min(minLat, p.lat); maxLat = max(maxLat, p.lat); minLon = min(minLon, p.lon); maxLon = max(maxLon, p.lon) }
        val bbox = String.format(java.util.Locale.US, "%.5f,%.5f,%.5f,%.5f", minLat - 0.01, minLon - 0.015, maxLat + 0.01, maxLon + 0.015)
        val pl = poly(line)
        val q = "[out:json][timeout:30];" +
            "(node(around:14,$pl)[\"traffic_calming\"~\"^(bump|hump|table|cushion)$\"];" +
            "node(around:90,$pl)[\"amenity\"=\"school\"];way(around:90,$pl)[\"amenity\"=\"school\"];)->.a;.a out center tags 300;" +
            "node(around:10,$pl)[\"highway\"=\"crossing\"][\"crossing\"~\"^(zebra|marked|traffic_signals|uncontrolled|pelican|toucan|puffin|pegasus)$\"]->.c;.c out body 400;" +
            "node(around:12,$pl)[\"highway\"=\"stop\"]->.s;.s out body 300;way(bn.s)[\"highway\"]->.sw;.sw out body geom 600;" +
            "(node(around:12,$pl)[\"railway\"=\"level_crossing\"];node(around:12,$pl)[\"ford\"=\"yes\"];way(around:12,$pl)[\"ford\"=\"yes\"];)->.f;.f out center tags 200;"
        // (average speed checks are no longer part of this big request: they have their own, see avgZones, so a slow or failed
        // search for bumps and schools can't take them down with it, GitHub #135)
        val els = Overpass.query(q, 12000, 40000, 3)
        val pois = ArrayList<RoutePoi>()
        // (crossings come from their own set, so they never crowd out the bumps and schools)
        val nodes = HashMap<Long, LL>()
        val rels = ArrayList<JSONObject>()
        // stop signs and the roads they're on, to keep only the ones for the way you're going (dubrava4ever, #178)
        val stopWays = ArrayList<JSONObject>()
        val stops = ArrayList<Triple<Long, LL, JSONObject>>()
        for (i in 0 until els.length()) {
            val e = els.getJSONObject(i)
            when (e.optString("type")) {
                "relation" -> rels += e
                "way" -> if (e.has("geometry") && e.has("nodes")) stopWays += e
                else -> {
                    val pos = if (e.has("lat")) LL(e.getDouble("lat"), e.getDouble("lon")) else e.optJSONObject("center")?.let { LL(it.getDouble("lat"), it.getDouble("lon")) }
                    if (pos != null && e.optString("type") == "node") nodes[e.optLong("id")] = pos
                    val t = e.optJSONObject("tags") ?: continue
                    if (pos == null) continue
                    if (t.optString("highway") == "stop") stops += Triple(e.optLong("id"), pos, t)
                    else if (t.optString("railway") == "level_crossing") pois += RoutePoi("rail", "Level crossing", pos)
                    else if (t.optString("ford") == "yes") pois += RoutePoi("ford", "Ford", pos)
                    else if (t.optString("highway") == "crossing") pois += RoutePoi("crossing", t.optString("crossing"), pos)
                    else if (t.has("traffic_calming")) pois += RoutePoi("bump", t.optString("traffic_calming"), pos)
                    else if (t.optString("amenity") == "school") pois += RoutePoi("school", t.optString("name").ifBlank { "School" }, pos)
                }
            }
        }
        for ((id, pos, t) in stops) if (try { stopForRoute(id, pos, t, stopWays, line) } catch (x: Exception) { true }) pois += RoutePoi("stop", "Stop", pos)
        return pois to parseAvgs(rels, nodes)
    }

    /**
     * Whether a stop sign is for you, not for a side road you pass (dubrava4ever, #178). A sign on a side street a few metres
     * before it meets your road was within reach of the route, so it warned. It's kept only when the road it's on runs the same
     * way as the route there (and its direction tag, if it has one, faces the way you're going). A sign drawn on the junction
     * itself, with no direction, can't say which road it's for, so it's only kept when it's a stop for everyone (stop=all).
     * With no road data for it, it's kept, as before.
     */
    private fun stopForRoute(id: Long, pos: LL, t: JSONObject, ways: List<JSONObject>, line: List<LL>): Boolean {
        // the route's heading at its closest point to the sign
        // (flat sums, no trigonometry: up to 300 signs against a long route, on a slow unit)
        if (line.size < 2) return true
        val kx = cos(Math.toRadians(pos.lat))
        var best = Double.MAX_VALUE; var bi = 0
        for (i in 0 until line.size - 1) {
            val p = line[i]; val q = line[i + 1]
            val ax = (p.lon - pos.lon) * kx; val ay = p.lat - pos.lat; val bx = (q.lon - pos.lon) * kx; val by = q.lat - pos.lat
            val d = hypot(ax, ay) + hypot(bx, by) - hypot(bx - ax, by - ay)
            if (d < best) { best = d; bi = i }
        }
        if (Geo.dist(line[bi], line[bi + 1]) < 0.5) return true
        val rb = Geo.bearing(line[bi], line[bi + 1])
        val dirTag = t.optString("direction").lowercase()
        val all = t.optString("stop") == "all"
        var onWays = 0
        var forUs = false
        for (w in ways) {
            val ids = w.getJSONArray("nodes"); val g = w.getJSONArray("geometry")
            var k = -1
            for (j in 0 until ids.length()) if (ids.optLong(j) == id) { k = j; break }
            if (k < 0 || g.length() < 2) continue
            onWays++
            val a = g.getJSONObject(max(k - 1, 0)); val b = g.getJSONObject(min(k + 1, g.length() - 1))
            val wb = Geo.bearing(LL(a.getDouble("lat"), a.getDouble("lon")), LL(b.getDouble("lat"), b.getDouble("lon")))
            val diff = abs(((wb - rb + 540.0) % 360.0) - 180.0)   // 0 = same way, 180 = opposite
            when {
                diff < 40.0 -> if (dirTag != "backward") forUs = true
                diff > 140.0 -> if (dirTag != "forward") forUs = true
            }
        }
        if (onWays == 0) return true
        if (!forUs) return false
        // on the junction itself (where roads meet) with no direction: only a stop for everyone is clearly yours
        if (onWays >= 2 && dirTag != "forward" && dirTag != "backward" && !all) return false
        return true
    }

    /**
     * The average speed checks round a stretch of route, in a small request of their own with a generous wait (busy Overpass servers
     * took 26 to 34 seconds for it, longer than the old 25-second limit), GitHub #135.
     */
    fun avgZones(line: List<LL>): List<AvgDef> {
        if (line.size < 2) return emptyList()
        var minLat = 90.0; var maxLat = -90.0; var minLon = 180.0; var maxLon = -180.0
        for (p in line) { minLat = min(minLat, p.lat); maxLat = max(maxLat, p.lat); minLon = min(minLon, p.lon); maxLon = max(maxLon, p.lon) }
        val bbox = String.format(java.util.Locale.US, "%.5f,%.5f,%.5f,%.5f", minLat - 0.01, minLon - 0.015, maxLat + 0.01, maxLon + 0.015)
        val els = Overpass.query("[out:json][timeout:40];rel($bbox)[\"enforcement\"=\"average_speed\"]->.r;.r out body;node(r.r);out skel qt;", 10000, 45000, 3)
        val nodes = HashMap<Long, LL>(); val rels = ArrayList<JSONObject>()
        for (i in 0 until els.length()) {
            val e = els.getJSONObject(i)
            if (e.optString("type") == "relation") rels += e
            else if (e.optString("type") == "node" && e.has("lat")) nodes[e.optLong("id")] = LL(e.getDouble("lat"), e.getDouble("lon"))
        }
        return parseAvgs(rels, nodes)
    }

    private fun parseAvgs(rels: List<JSONObject>, nodes: Map<Long, LL>): List<AvgDef> {
        val avgs = ArrayList<AvgDef>()
        for (rel in rels) {
            val ms = rel.optJSONArray("members") ?: continue
            val from = ArrayList<LL>(); val to = ArrayList<LL>(); val dev = ArrayList<LL>()
            for (k in 0 until ms.length()) {
                val m = ms.getJSONObject(k)
                if (m.optString("type") != "node") continue
                val p = nodes[m.optLong("ref")] ?: continue
                when (m.optString("role")) { "from" -> from += p; "to" -> to += p; else -> dev += p }
            }
            val t = rel.optJSONObject("tags") ?: JSONObject()
            val starts = from.ifEmpty { dev }; val ends = to.ifEmpty { dev }
            if (starts.isEmpty() || ends.isEmpty()) continue
            // read in the country the check is in: it was always read as British, where a limit with no unit is in mph, so a
            // 60 km/h check elsewhere came out as 60 mph and showed as 95 km/h (GitHub #106)
            val lim = t.optString("maxspeed").takeIf { it.isNotBlank() }?.let { Overpass.parseSpeed(it, Overpass.countryAt(starts.first())) }
            avgs += AvgDef(rel.optLong("id"), t.optString("name").ifBlank { "Average speed check" }, starts, ends, lim)
        }
        return avgs
    }

    /** Places an average speed check on the route: it runs from its first start point to its last end point. */
    fun placeAvg(r: Route, d: AvgDef): AvgOnRoute? {
        val s = d.starts.mapNotNull { project(r, it, 80.0)?.first }.minOrNull() ?: return null
        val e = d.ends.mapNotNull { project(r, it, 80.0)?.first }.maxOrNull() ?: return null
        return if (e - s in 400.0..60_000.0) AvgOnRoute(d, s, e) else null
    }

    /** True on weekday school-run times (term dates are not known, so holidays are included). */
    fun schoolTime(now: Long): Boolean {
        val c = java.util.Calendar.getInstance().apply { timeInMillis = now }
        val d = c.get(java.util.Calendar.DAY_OF_WEEK)
        if (d == java.util.Calendar.SATURDAY || d == java.util.Calendar.SUNDAY) return false
        val m = c.get(java.util.Calendar.HOUR_OF_DAY) * 60 + c.get(java.util.Calendar.MINUTE)
        return m in (8 * 60)..(9 * 60 + 30) || m in (14 * 60 + 45)..(16 * 60 + 15)
    }

    /** Compass point for a heading in degrees. */
    fun compass(h: Double): String = arrayOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")[(((h % 360.0) + 360.0 + 22.5) / 45.0).toInt() % 8]
}


/** Bends on a route that are not junctions: (distance along the route, -1 left / +1 right). */
fun routeBends(r: Route): List<Pair<Double, Int>> {
    val n = r.pts.size
    if (n < 3) return emptyList()
    val out = ArrayList<Pair<Double, Int>>()
    val span = 35.0
    var a = 0; var b = 0
    var lastAt = -1e9
    val stepOffs = r.steps.map { it.off }
    var si = 0
    for (i in 1 until n - 1) {
        val c = r.cum[i]
        while (a < i && r.cum[a] < c - span) a++
        if (b < i) b = i
        while (b < n - 1 && r.cum[b] < c + span) b++
        if (a >= i || b <= i || c - r.cum[a] < span * 0.6 || r.cum[b] - c < span * 0.6) continue
        val h1 = Geo.bearing(r.pts[a], r.pts[i]); val h2 = Geo.bearing(r.pts[i], r.pts[b])
        val d = (h2 - h1 + 540.0) % 360.0 - 180.0
        if (abs(d) < 48.0 || c - lastAt < 150.0) continue
        while (si < stepOffs.size - 1 && stepOffs[si] < c - 60.0) si++
        if (stepOffs.isNotEmpty() && abs(stepOffs[si] - c) < 60.0) continue   // that's a junction, not a bend
        lastAt = c
        out += c to (if (d < 0) -1 else 1)
    }
    return out
}

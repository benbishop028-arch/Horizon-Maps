# Changelog

## Source repository baseline

- Added the Android project files as reviewable source rather than relying solely on ZIP snapshots.
- Added repository setup/build notes and ignore rules for generated files and local signing material.
- This baseline is a source snapshot; historical changes were not reconstructed from ZIP-only commits.
